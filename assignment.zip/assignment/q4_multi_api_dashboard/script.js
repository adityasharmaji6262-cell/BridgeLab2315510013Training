const endpoints = [
  {url: 'http://localhost:3004/users', key: 'users', field: 'users'},
  {url: 'http://localhost:3005/orders', key: 'orders', field: 'orders'},
  {url: 'http://localhost:3006/products', key: 'products', field: 'products'}
];

const usersEl = document.getElementById('users');
const ordersEl = document.getElementById('orders');
const productsEl = document.getElementById('products');
const warnEl = document.getElementById('warn');

function showData(results, hadError){
  if(hadError) warnEl.textContent = 'Some data could not be loaded.';
  // users
  try {
    const u = results[0];
    usersEl.textContent = Array.isArray(u) ? u.length : Object.keys(u || {}).length;
  } catch(e){ usersEl.textContent = '—'; }
  // orders
  try {
    const o = results[1];
    ordersEl.textContent = Array.isArray(o) ? o.length : Object.keys(o || {}).length;
  } catch(e){ ordersEl.textContent = '—'; }
  // products
  try {
    const p = results[2];
    productsEl.textContent = Array.isArray(p) ? p.length : Object.keys(p || {}).length;
  } catch(e){ productsEl.textContent = '—'; }
}

// Fetch all simultaneously
Promise.all(endpoints.map(ep => fetch(ep.url).then(r => {
  if(!r.ok) throw new Error('Failed');
  return r.json();
}).then(js => {
  // return the array inside or the object directly
  if(js[epKeyName(js)]) return js[epKeyName(js)];
  return js;
}).catch(err => { return {__error:true}; } )))
.then(results => {
  // normalize results: if object with key array, extract arrays
  const normalized = results.map(r => {
    if(r && r.__error) return null;
    if(typeof r === 'object') {
      // try to return array inside
      const vals = Object.values(r).find(v=>Array.isArray(v));
      return vals || r;
    }
    return r;
  });
  const hadError = normalized.some(x=>x===null);
  showData(normalized, hadError);
})
.catch(e=>{
  warnEl.textContent = 'Some data could not be loaded.';
});

// helper to guess key
function epKeyName(obj){
  return Object.keys(obj)[0];
}
