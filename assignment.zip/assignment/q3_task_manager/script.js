$(function(){
  const $list = $('#list');
  const $filter = $('#filter');
  const API = 'http://localhost:3003/tasks';

  function load(query){
    let url = API;
    if(query) url += '?' + query;
    $.ajax({ url: url, method: 'GET', dataType: 'json', success: function(data){
      render(data);
    }, error: function(){ $list.html('<li>Error loading tasks</li>'); }
    });
  }

  function render(tasks){
    $list.empty();
    if(!tasks || tasks.length === 0){
      $list.html('<li>No tasks found</li>');
      return;
    }
    tasks.forEach(t => {
      const $li = $(`
        <li data-id="${t.id}">
          <input type="checkbox" ${t.completed ? 'checked' : ''} class="chk"> <strong>${t.title}</strong>
          <div>Priority: ${t.priority}</div>
        </li>
      `);
      $li.find('.chk').on('change', function(){
        const newCompleted = this.checked;
        $.ajax({
          url: API + '/' + t.id,
          method: 'PATCH',
          contentType: 'application/json; charset=utf-8',
          data: JSON.stringify({ completed: newCompleted }),
          success: function(){ /* UI already updated by checkbox state */ },
          error: function(){ alert('Failed to update task'); $(this).prop('checked', !newCompleted); }
        });
      });
      $list.append($li);
    });
  }

  $filter.on('change', function(){
    load($(this).val());
  });

  load();
});
