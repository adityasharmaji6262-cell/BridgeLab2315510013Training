const API = 'http://localhost:3008/users';
const form = document.getElementById('form');
const msg = document.getElementById('msg');
form.addEventListener('submit', function(e){
  e.preventDefault();
  const fd = new FormData(form);
  const user = { name: fd.get('name'), email: fd.get('email'), password: fd.get('password') };
  // check duplicate
  axios.get(API + '?email=' + encodeURIComponent(user.email))
    .then(res=>{
      if(res.data && res.data.length > 0){
        msg.textContent = 'Email already registered.';
        msg.style.color = 'red';
      } else {
        axios.post(API, user).then(r=>{
          msg.textContent = 'Registered successfully.';
          msg.style.color = 'green';
          form.reset();
        }).catch(err=>{
          msg.textContent = 'Registration failed.';
          msg.style.color = 'red';
        });
      }
    }).catch(err=>{
      msg.textContent = 'Error checking email.';
      msg.style.color = 'red';
    });
});
