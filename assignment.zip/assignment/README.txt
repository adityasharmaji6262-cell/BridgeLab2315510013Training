Assignment package for Q1-Q6 (JSON Server + frontend).

Run each JSON Server with the corresponding db file on different ports as shown below:

Q1 (products)   -> json-server --watch q1_live_search/db.json --port 3001
Q2 (employees)  -> json-server --watch q2_employee_dashboard/db.json --port 3002
Q3 (tasks)      -> json-server --watch q3_task_manager/db.json --port 3003
Q4 (users)      -> json-server --watch q4_multi_api_dashboard/users.json --port 3004
Q4 (orders)     -> json-server --watch q4_multi_api_dashboard/orders.json --port 3005
Q4 (products)   -> json-server --watch q4_multi_api_dashboard/products.json --port 3006
Q5 (timetable)  -> json-server --watch q5_timetable_viewer/db.json --port 3007
Q6 (users)      -> json-server --watch q6_registration/db.json --port 3008

Then open the corresponding index.html in the browser for each question folder.
