const daySelect = document.getElementById('day');
const list = document.getElementById('list');
function load(day){
  fetch('http://localhost:3007/timetable?day=' + encodeURIComponent(day))
    .then(r=>r.json())
    .then(data=>{
      render(data);
    }).catch(e=>{
      list.innerHTML = '<div>Error loading timetable</div>';
    });
}
function render(items){
  list.innerHTML = '';
  if(!items || items.length === 0){
    list.innerHTML = '<div>No classes today.</div>';
    return;
  }
  items.forEach(it=>{
    const d = document.createElement('div');
    d.className = 'row';
    d.innerHTML = `<strong>${it.subject}</strong> — ${it.faculty} <div>${it.time}</div>`;
    list.appendChild(d);
  });
}
daySelect.addEventListener('change', ()=> load(daySelect.value));
// initial
load(daySelect.value);
