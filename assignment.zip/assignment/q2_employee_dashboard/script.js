(function(){
  const API = 'http://localhost:3002/employees';
  const tbody = document.querySelector('#tbl tbody');
  const errEl = document.getElementById('error');

  function showError(msg){
    errEl.textContent = msg;
    setTimeout(()=> errEl.textContent = '', 4000);
  }

  function fetchEmployees(){
    const xhr = new XMLHttpRequest();
    xhr.open('GET', API);
    xhr.onload = function(){
      if(xhr.status >=200 && xhr.status < 300){
        const employees = JSON.parse(xhr.responseText);
        render(employees);
      } else {
        showError('Failed to load employees');
      }
    };
    xhr.onerror = function(){ showError('Network error while fetching employees'); };
    xhr.send();
  }

  function render(employees){
    tbody.innerHTML = '';
    employees.forEach(emp => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>${emp.name}</td>
        <td class="status">${emp.status}</td>
        <td><input type="checkbox" ${emp.status === 'active' ? 'checked' : ''}></td>
      `;

      const chk = tr.querySelector('input[type=checkbox]');
      const statusTd = tr.querySelector('.status');

      chk.addEventListener('change', function(){
        // optimistic UI update
        const newStatus = this.checked ? 'active' : 'inactive';
        const prevStatus = statusTd.textContent;
        statusTd.textContent = newStatus;

        // send PATCH
        const patchXhr = new XMLHttpRequest();
        patchXhr.open('PATCH', API + '/' + emp.id);
        patchXhr.setRequestHeader('Content-Type', 'application/json;charset=UTF-8');
        patchXhr.onload = function(){
          if(!(patchXhr.status >=200 && patchXhr.status < 300)){
            // revert on failure
            statusTd.textContent = prevStatus;
            chk.checked = prevStatus === 'active';
            showError('Failed to update status');
          }
        };
        patchXhr.onerror = function(){
          statusTd.textContent = prevStatus;
          chk.checked = prevStatus === 'active';
          showError('Network error while updating');
        };
        patchXhr.send(JSON.stringify({ status: newStatus }));
      });

      tbody.appendChild(tr);
    });
  }

  // initial load
  fetchEmployees();
})();
