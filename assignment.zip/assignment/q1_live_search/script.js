$(function(){
  const $input = $('#search');
  const $results = $('#results');
  const $loading = $('#loading');
  let lastXhr = null;

  $input.on('input', function(){
    const q = $(this).val().trim();

    // show loading
    $loading.show();

    // cancel previous request if exists
    if(lastXhr && lastXhr.readyState !== 4){
      lastXhr.abort();
    }

    lastXhr = $.ajax({
      url: 'http://localhost:3001/products',
      data: { q: q },
      method: 'GET',
      dataType: 'json',
      success: function(data){
        $loading.hide();
        $results.empty();
        if(!data || data.length === 0){
          $results.text('No products found');
          return;
        }
        data.forEach(p => {
          const $el = $(
            `<div class="product">
              <img src="${p.image}" width="80" height="80" />
              <div>
                <div><strong>${p.name}</strong></div>
                <div>₹ ${p.price}</div>
              </div>
            </div>`
          );
          $results.append($el);
        });
      },
      error: function(xhr, status){
        if(status !== 'abort'){
          $loading.hide();
          $results.text('Error loading products');
        }
      }
    });
  });
});
